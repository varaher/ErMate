const fs = require('fs');
let code = fs.readFileSync('src/components/CaseSheetView.tsx', 'utf8');
code = code.replace('\\nexport default function CaseSheetView({', '\nexport default function CaseSheetView({');
fs.writeFileSync('src/components/CaseSheetView.tsx', code);
